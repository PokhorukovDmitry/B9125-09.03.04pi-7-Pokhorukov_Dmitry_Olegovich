#ifndef _VOLUMES_H_
#define _VOLUMES_H_

double CubeVolume(double a);
double ParallelepipedVolume(double a, double b, double c);
double PrismVolume(double a, double b, double h);

#endif